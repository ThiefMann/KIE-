Long Rim Mech Data for Comp/Con
